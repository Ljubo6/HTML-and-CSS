# 01. Media Query Less Layout Using Flexbox
------
Problems for in-class lab for the [�Web Fundamentals - HTML 5�](https://softuni.bg/trainings/2265/web-fundamentals-html5-january-2019/) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1236/Flexbox).

## Tasks
* Create an **"index.html"** file with title - **Media Query Less Layout Using Flexbox**
* Set to the body display property **flex**


## Constraints
* Create a HTML [layout](https://www.w3schools.com/html/html_layout.asp) using semantic elements