# 01 - Semantic Tags
------
Problems for in-class lab for the [“Web Fundamentals - HTML 5”](https://softuni.bg/trainings/2265/web-fundamentals-html5-january-2019/) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1458/HTML-Tags-Semantic-Markup).

## Constraints
* Create an **index.html** file with **Semantic Tags** title
* Create header section with a **header** tag 
    * Use **h1** tag for heading
* Create a main section with a **main** tag
    * Create two paragraphs inside
* Use **aside** tag for the third section with exactly one paragraph inside 
* Use **footer** tag for the last section
    * Create two paragraphs inside
   




