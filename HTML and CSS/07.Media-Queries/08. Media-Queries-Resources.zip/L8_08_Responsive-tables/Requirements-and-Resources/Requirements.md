# 08 - Responsive tables
------
Problems for in-class lab for the [�Web Fundamentals - HTML 5�](https://softuni.bg/trainings/2265/web-fundamentals-html5-january-2019/) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1239/Media-Queries).

## Tasks
* Create an **"index.html"** file with title - **Responsive tables**
* Create a table with 3 columns, First Name, Last Name, Job Title
* Get the latest reset css
* Get the latest typography css
* Make the table responsive
