# 11 - Fonts Speciment - Great Vibes + Raleway
------
Problems for in-class lab for the [�Web Fundamentals - HTML 5�](https://softuni.bg/trainings/2265/web-fundamentals-html5-january-2019/) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1234/CSS-Typography).

## Tasks
* Create an **index.html** file with **Fonts Speciment Great Vibes + Raleway** title 
* Use **"Raleway", sans-serif**  font-family for the document
	* Make the **font-size** 16px
	* Change the **line-height** to 1.5
* Use **"Great Vibes", cursive** font-family for the headings
	* Make the **font-size** 1em
	* Change the **line-height** to 1.2
	* Change the font weight to **bold**
