# 05 - Contrasting Colors
------
Problems for in-class lab for the [�Web Fundamentals - HTML 5�](https://softuni.bg/trainings/2265/web-fundamentals-html5-january-2019/) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1234/CSS-Typography).

## Tasks
* Create an **index.html** file with **Contrasting Colors** title 
* Create an **article** inside the body
	* Make the background with **rgb(51, 102, 153)** color
	* Set the border radius to **1rem**
* Use **"Helvetica",sans-serif**  font-family for the document
	* Make the **font-size** 16px
	* Change the **line-height** to 1.5
* Use **"Georgia", serif** font-family for the headings